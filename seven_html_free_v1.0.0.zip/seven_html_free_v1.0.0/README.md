# Seven HTML Free  - Bootstrap 5 HTML Multipurpose Light/Dark Admin Dashboard Theme

- For a quick start please check [Online documentation](//preview.keenthemes.com/seven-html-free/documentation/getting-started.html)

- For more amazing features and solutions, please upgrade to [Seven HTML Pro](//keenthemes.com/products/seven-html-pro)

- Stay tuned for updates via [Twitter](//twitter.com/keenthemes), [Instagram](//instagram.com/keenthemes), [Dribbble](//dribbble.com/keenthemes) and [Facebook](//facebook.com/keenthemes)

# More Templates & Graphics

Check out our market for more free and pro templates and graphics: [Keenthemes Market](//keenthemes.com).

# Copyright & License

copyright 2021 Keenthemes. The code is released under the MIT license. There is only one limitation that you can not use the code as it is, modified or part of other item to re-distribute or resell as stock item. 

Happy coding with Seven HTML Free!