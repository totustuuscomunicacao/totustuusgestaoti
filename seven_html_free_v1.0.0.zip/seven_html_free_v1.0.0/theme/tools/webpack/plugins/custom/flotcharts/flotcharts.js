// Flot- Flot is a pure JavaScript plotting library for jQuery, with a focus on simple usage, attractive looks and interactive features: https://www.flotcharts.org/

require('flot/dist/es5/jquery.flot.js');
require('flot/source/jquery.flot.resize.js');
require('flot/source/jquery.flot.categories.js');
require('flot/source/jquery.flot.pie.js');
require('flot/source/jquery.flot.stack.js');
require('flot/source/jquery.flot.crosshair.js');
require('flot/source/jquery.flot.axislabels.js');
