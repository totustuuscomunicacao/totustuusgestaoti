// Cropper -  A simple jQuery image cropping plugin: https://fengyuanchen.github.io/cropper/

window.Cropper = require('cropperjs/dist/cropper.js');

require('./cropper.scss');
